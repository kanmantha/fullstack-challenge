using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SloozeFoodApp.Data;
using SloozeFoodApp.Models;
using SloozeFoodApp.Services;

namespace SloozeFoodApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly JwtService _jwt;

        public AuthController(AppDbContext db, JwtService jwt)
        {
            _db = db;
            _jwt = jwt;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto model)
        {
            var user = await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Username == model.Username);
            if (user == null) return Unauthorized(new { message = "Invalid credentials" });

            if (!BCrypt.Net.BCrypt.Verify(model.Password, user.PasswordHash))
                return Unauthorized(new { message = "Invalid credentials" });

            var token = _jwt.GenerateToken(user, user.Role!);
            return Ok(new { token, role = user.Role!.Name, country = user.CountryCode });
        }
    }

    public record LoginDto(string Username, string Password);
}
