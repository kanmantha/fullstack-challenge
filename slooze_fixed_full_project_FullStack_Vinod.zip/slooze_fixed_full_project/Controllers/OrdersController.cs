using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SloozeFoodApp.Data;
using SloozeFoodApp.Models;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

namespace SloozeFoodApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbContext _db;

        public OrdersController(AppDbContext db) => _db = db;

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CreateOrder([FromBody] CreateOrderDto dto)
        {
            var userId = int.Parse(User.FindFirstValue(JwtRegisteredClaimNames.Sub));
            var user = await _db.Users.FindAsync(userId);
            if (user == null) return Unauthorized();

            var restaurant = await _db.Restaurants.FindAsync(dto.RestaurantId);
            if (restaurant == null) return BadRequest("Invalid restaurant");

            var countryClaim = User.FindFirst("country")?.Value ?? "ALL";
            if (countryClaim != "ALL" && countryClaim != restaurant.CountryCode) return Forbid();

            var order = new Order
            {
                UserId = userId,
                RestaurantId = restaurant.Id,
                CountryCode = restaurant.CountryCode,
                Status = OrderStatus.Created,
                CreatedAt = DateTime.UtcNow
            };

            decimal total = 0M;
            foreach (var it in dto.Items)
            {
                var menuItem = await _db.MenuItems.FindAsync(it.MenuItemId);
                if (menuItem == null) return BadRequest($"MenuItem {it.MenuItemId} not found");
                var oi = new OrderItem
                {
                    MenuItemId = menuItem.Id,
                    Quantity = it.Quantity,
                    UnitPrice = menuItem.Price
                };
                order.Items.Add(oi);
                total += oi.Quantity * oi.UnitPrice;
            }

            order.TotalAmount = total;
            _db.Orders.Add(order);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = order.Id }, order);
        }

        [HttpPost("{id}/checkout")]
        [Authorize(Policy = "CanPlaceOrder")]
        public async Task<IActionResult> Checkout(int id)
        {
            var order = await _db.Orders.Include(o => o.Restaurant).Include(o => o.User).FirstOrDefaultAsync(o => o.Id == id);
            if (order == null) return NotFound();

            var country = User.FindFirst("country")?.Value ?? "ALL";
            if (country != "ALL" && order.CountryCode != country) return Forbid();

            if (order.Status != OrderStatus.Created) return BadRequest("Order not in created state");

            order.Status = OrderStatus.Placed;
            await _db.SaveChangesAsync();
            return Ok(order);
        }

        [HttpPost("{id}/cancel")]
        [Authorize]
        public async Task<IActionResult> Cancel(int id)
        {
            var role = User.FindFirst(ClaimTypes.Role)?.Value ?? "";
            if (role != "Admin" && role != "Manager") return Forbid();

            var order = await _db.Orders.Include(o => o.Restaurant).FirstOrDefaultAsync(o => o.Id == id);
            if (order == null) return NotFound();

            var country = User.FindFirst("country")?.Value ?? "ALL";
            if (country != "ALL" && order.CountryCode != country) return Forbid();

            order.Status = OrderStatus.Canceled;
            await _db.SaveChangesAsync();
            return Ok(order);
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> List()
        {
            var role = User.FindFirst(ClaimTypes.Role)?.Value ?? "";
            var country = User.FindFirst("country")?.Value ?? "ALL";
            if (role == "Admin" || country == "ALL")
            {
                var all = await _db.Orders.Include(o => o.Items).ToListAsync();
                return Ok(all);
            }
            else
            {
                var list = await _db.Orders.Where(o => o.CountryCode == country).Include(o => o.Items).ToListAsync();
                return Ok(list);
            }
        }

        [HttpGet("{id}")]
        [Authorize]
        public async Task<IActionResult> GetById(int id)
        {
            var order = await _db.Orders.Include(o => o.Items).FirstOrDefaultAsync(o => o.Id == id);
            if (order == null) return NotFound();
            var country = User.FindFirst("country")?.Value ?? "ALL";
            if (country != "ALL" && order.CountryCode != country) return Forbid();
            return Ok(order);
        }
    }

    public record CreateOrderDto(int RestaurantId, List<OrderItemDto> Items);
    public record OrderItemDto(int MenuItemId, int Quantity);
}
