using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SloozeFoodApp.Data;
using SloozeFoodApp.Models;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

namespace SloozeFoodApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentController : ControllerBase
    {
        private readonly AppDbContext _db;

        public PaymentController(AppDbContext db) => _db = db;

        [HttpGet("me")]
        [Authorize]
        public async Task<IActionResult> GetMyPayment()
        {
            var userId = int.Parse(User.FindFirstValue(JwtRegisteredClaimNames.Sub));
            var pm = await _db.PaymentMethods.FirstOrDefaultAsync(p => p.UserId == userId);
            return Ok(pm);
        }

        [HttpPut("users/{userId}/methods/{methodId}")]
        [Authorize(Policy = "CanUpdatePayment")]
        public async Task<IActionResult> UpdatePayment(int userId, int methodId, [FromBody] PaymentUpdateDto dto)
        {
            var pm = await _db.PaymentMethods.FirstOrDefaultAsync(p => p.Id == methodId && p.UserId == userId);
            if (pm == null) return NotFound();

            pm.Type = dto.Type ?? pm.Type;
            pm.DetailsMasked = dto.DetailsMasked ?? pm.DetailsMasked;
            await _db.SaveChangesAsync();
            return Ok(pm);
        }
    }

    public record PaymentUpdateDto(string? Type, string? DetailsMasked);
}
