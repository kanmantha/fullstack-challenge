using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SloozeFoodApp.Data;
using SloozeFoodApp.Models;
using System.Security.Claims;

namespace SloozeFoodApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RestaurantsController : ControllerBase
    {
        private readonly AppDbContext _db;

        public RestaurantsController(AppDbContext db) => _db = db;


        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetRestaurants()
        {
            var role = User.FindFirst(ClaimTypes.Role)?.Value ?? "";
            var country = User.FindFirst("country")?.Value ?? "ALL";

            IQueryable<Restaurant> q = _db.Restaurants.Include(r => r.Menu).OrderBy(r => r.Id);

            if (country != "ALL" && role != "Admin")
                q = q.Where(r => r.CountryCode == country);

            var result = await q.Select(r => new {
                r.Id,
                r.Name,
                r.CountryCode,
                Menu = r.Menu.Select(m => new {
                    m.Id,
                    m.Name,
                    m.Description,
                    m.Price,
                    m.IsAvailable
                }).ToList()
            }).ToListAsync();

            return Ok(result);
        }

    


        [HttpGet("{id}")]
        [Authorize]
        public async Task<IActionResult> GetById(int id)
        {
            var r = await _db.Restaurants.Include(x => x.Menu).FirstOrDefaultAsync(x => x.Id == id);
            if (r == null) return NotFound();
            var country = User.FindFirst("country")?.Value ?? "ALL";
            if (country != "ALL" && r.CountryCode != country) return Forbid();
            return Ok(r);
        }

        [HttpGet("{id}/menu")]
        [Authorize]
        public async Task<IActionResult> GetMenu(int id)
        {
            var r = await _db.Restaurants.Include(x => x.Menu).FirstOrDefaultAsync(x => x.Id == id);
            if (r == null) return NotFound();
            var country = User.FindFirst("country")?.Value ?? "ALL";
            if (country != "ALL" && r.CountryCode != country) return Forbid();
            return Ok(r.Menu);
        }
    }
}
