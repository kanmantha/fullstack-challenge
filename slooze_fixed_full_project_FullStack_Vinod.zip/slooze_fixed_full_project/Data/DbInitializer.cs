using BCrypt.Net;
using SloozeFoodApp.Models;

namespace SloozeFoodApp.Data
{
    public static class DbInitializer
    {
        public static void Seed(AppDbContext db)
        {
            if (db.Roles.Any()) return;

            var admin = new Role { Name = "Admin" };
            var manager = new Role { Name = "Manager" };
            var member = new Role { Name = "Member" };
            db.Roles.AddRange(admin, manager, member);
            db.SaveChanges();

            var inCountry = new Country { Code = "IN", Name = "India" };
            var usCountry = new Country { Code = "US", Name = "America" };
            var all = new Country { Code = "ALL", Name = "Global" };
            db.Countries.AddRange(inCountry, usCountry, all);
            db.SaveChanges();

            string pwHash = BCrypt.Net.BCrypt.HashPassword("Password123!");
            var nick = new User { Username = "nick", Email = "nick@stark.io", PasswordHash = pwHash, RoleId = admin.Id, CountryCode = "ALL" };
            var capmarvel = new User { Username = "capmarvel", Email = "cm@corp", PasswordHash = pwHash, RoleId = manager.Id, CountryCode = "IN" };
            var capamerica = new User { Username = "capamerica", Email = "ca@corp", PasswordHash = pwHash, RoleId = manager.Id, CountryCode = "US" };
            var thanos = new User { Username = "thanos", Email = "thanos@corp", PasswordHash = pwHash, RoleId = member.Id, CountryCode = "IN" };
            var thor = new User { Username = "thor", Email = "thor@corp", PasswordHash = pwHash, RoleId = member.Id, CountryCode = "IN" };
            var travis = new User { Username = "travis", Email = "travis@corp", PasswordHash = pwHash, RoleId = member.Id, CountryCode = "US" };

            db.Users.AddRange(nick, capmarvel, capamerica, thanos, thor, travis);
            db.SaveChanges();

            var r1 = new Restaurant { Name = "Bombay Bites", CountryCode = "IN" };
            var r2 = new Restaurant { Name = "Delhi Dhaba", CountryCode = "IN" };
            var r3 = new Restaurant { Name = "NY Pizza", CountryCode = "US" };
            var r4 = new Restaurant { Name = "LA Tacos", CountryCode = "US" };
            db.Restaurants.AddRange(r1, r2, r3, r4);
            db.SaveChanges();

            db.MenuItems.AddRange(
                new MenuItem { RestaurantId = r1.Id, Name = "Butter Chicken", Description = "Rich gravy", Price = 8.99m, IsAvailable = true },
                new MenuItem { RestaurantId = r1.Id, Name = "Naan", Description = "Tandoori bread", Price = 1.50m, IsAvailable = true },
                new MenuItem { RestaurantId = r3.Id, Name = "Pepperoni Pizza", Description = "Large", Price = 10.50m, IsAvailable = true },
                new MenuItem { RestaurantId = r4.Id, Name = "Fish Taco", Description = "Grilled fish", Price = 5.00m, IsAvailable = true }
            );
            db.SaveChanges();

            db.PaymentMethods.Add(new PaymentMethod { UserId = nick.Id, Type = "Card", DetailsMasked = "**** **** **** 4242" });
            db.SaveChanges();
        }
    }
}
