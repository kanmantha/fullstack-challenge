﻿//using Microsoft.EntityFrameworkCore.Migrations;
//using System.Data;

//#nullable disable

//namespace SloozeFoodApp.Migrations
//{
//    /// <inheritdoc />
//    public partial class Users : Migration
//    {
//        /// <inheritdoc />
//        protected override void Up(MigrationBuilder migrationBuilder)
//        {
//            migrationBuilder.Sql("DROP TABLE IF EXISTS \"Users\";");
//            migrationBuilder.Sql("DROP TABLE IF EXISTS \"Roles\";");
//            // Defensive: drop index if it exists (no-op if not)
//            migrationBuilder.Sql("DROP INDEX IF EXISTS \"IX_Users_Username\";");


//            // Create Users table
//            migrationBuilder.CreateTable(
//                name: "Users",
//                columns: table => new
//                {
//                    Id = table.Column<int>(nullable: false)
//                        .Annotation("Sqlite:Autoincrement", true),
//                    Username = table.Column<string>(nullable: false),
//                    PasswordHash = table.Column<string>(nullable: true),
//                    Email = table.Column<string>(nullable: true),
//                    CreatedAt = table.Column<DateTime>(nullable: false)
//                    // add other columns to match your model
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_Users", x => x.Id);
//                });

//            // Create the unique index AFTER the table exists
//            migrationBuilder.CreateIndex(
//                name: "IX_Users_Username",
//                table: "Users",
//                column: "Username",
//                unique: true);

//            // Defensive: drop index if it exists (no-op if not)
//            migrationBuilder.Sql("DROP INDEX IF EXISTS \"IX_Users_Username\";");

//            // Create unique index if not exists (modern SQLite)
//            migrationBuilder.Sql("CREATE UNIQUE INDEX IF NOT EXISTS \"IX_Users_Username\" ON \"Users\" (\"Username\");");


//            // 2) then create index (use IF NOT EXISTS to be safe on re-runs)
//            //migrationBuilder.Sql("CREATE UNIQUE INDEX IF NOT EXISTS \"IX_Users_Username\" ON \"Users\" (\"Username\");");

//            // 3) any seeding that depends on Users should come after the table is created
//            // migrationBuilder.InsertData(...);

//            migrationBuilder.Sql("DROP INDEX IF EXISTS \"IX_Users_Username\";");
//            migrationBuilder.Sql("CREATE UNIQUE INDEX IF NOT EXISTS \"IX_Users_Username\" ON \"Users\" (\"Username\");");




//            // Create Roles table
//            migrationBuilder.CreateTable(
//                name: "Roles",
//                columns: table => new
//                {
//                    Id = table.Column<int>(nullable: false)
//                        .Annotation("Sqlite:Autoincrement", true),
//                    Name = table.Column<string>(nullable: false)
//                },
//                constraints: table =>
//                {
//                    table.PrimaryKey("PK_Roles", x => x.Id);
//                });

//            // Create unique index on Roles.Name
//            migrationBuilder.CreateIndex(
//                name: "IX_Roles_Name",
//                table: "Roles",
//                column: "Name",
//                unique: true);

//        }

//        /// <inheritdoc />
//        protected override void Down(MigrationBuilder migrationBuilder)
//        {
//            migrationBuilder.Sql("DROP INDEX IF EXISTS \"IX_Users_Username\";");
//            // ... other undo operations

//            migrationBuilder.DropTable(name: "Roles");
//        }
//    }
//}





using Microsoft.EntityFrameworkCore.Migrations;
using System.Data;

#nullable disable

namespace SloozeFoodApp.Migrations
{
    /// <inheritdoc />
    public partial class Users : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Skip if PaymentMethods already exists to avoid migration error on partially-applied DBs
            migrationBuilder.Sql(@"
        -- create PaymentMethods if not exists (idempotent)
        CREATE TABLE IF NOT EXISTS ""PaymentMethods"" (
          ""Id"" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
          ""UserId"" INTEGER NOT NULL,
          ""Type"" TEXT,
          ""Details"" TEXT,
          ""CreatedAt"" TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY(""UserId"") REFERENCES ""Users""(""Id"") ON DELETE CASCADE
        );
        CREATE UNIQUE INDEX IF NOT EXISTS ""IX_PaymentMethods_UserId"" ON ""PaymentMethods"" (""UserId"");
    ");
            // NOTE: This migration was edited to be idempotent for SQLite.
            // It uses CREATE TABLE IF NOT EXISTS and CREATE UNIQUE INDEX IF NOT EXISTS
            // to avoid failing on databases that already contain these objects.

            // Ensure Roles table
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS ""Roles"" (
                    ""Id"" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    ""Name"" TEXT NOT NULL UNIQUE
                );
            ");

            // Ensure Users table (minimal set of columns used by the app)
            // CreatedAt is NOT NULL with a default so existing rows are valid.
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS ""Users"" (
                    ""Id"" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    ""Username"" TEXT NOT NULL UNIQUE,
                    ""PasswordHash"" TEXT,
                    ""Email"" TEXT,
                    ""CountryCode"" TEXT,
                    ""PaymentMethodId"" INTEGER,
                    ""RoleId"" INTEGER,
                    ""CreatedAt"" TEXT NOT NULL DEFAULT (datetime('now')),
                    FOREIGN KEY(""RoleId"") REFERENCES ""Roles""(""Id"")
                );
            ");

            // Defensive: create unique index on Username if not exists
            migrationBuilder.Sql(@"CREATE UNIQUE INDEX IF NOT EXISTS ""IX_Users_Username"" ON ""Users"" (""Username"");");

            // Defensive: create unique index on Roles.Name if not exists
            migrationBuilder.Sql(@"CREATE UNIQUE INDEX IF NOT EXISTS ""IX_Roles_Name"" ON ""Roles"" (""Name"");");


            // Skipped adding Users.CreatedAt because the column already exists in some DBs.
            // This migration is made idempotent to avoid SQLite 'duplicate column' errors.
            migrationBuilder.Sql("/* Skipped adding Users.CreatedAt - already present */");


        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Avoid destructive drops in environments with existing data
            migrationBuilder.Sql("/* Down(): skipping drop of PaymentMethods for safety */");

            // To keep this migration safe across environments we avoid destructive
            // drops in Down(). If you truly want Down() to reverse Up() (drop tables),
            // be aware that doing so will delete data on environments where tables exist.
            //
            // For now we intentionally no-op the destructive operations to prevent accidental data loss.
            migrationBuilder.Sql("/* Down(): intentionally no-op to avoid dropping tables in environments that already have data. */");

            // Intentionally no-op to avoid dropping the column in environments where it existed before this migration.
            migrationBuilder.Sql("/* Down: skipped dropping Users.CreatedAt for safety */");
        }
    }
}

