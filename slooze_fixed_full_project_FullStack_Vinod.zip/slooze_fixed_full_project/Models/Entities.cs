using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SloozeFoodApp.Models
{
    public class Role
    {
        public int Id { get; set; }
        [Required] public string Name { get; set; } = default!;
    }

    public class Country
    {
        [Key] public string Code { get; set; } = default!;
        public string Name { get; set; } = default!;
    }

    public class User : IHasCountry
    {
        public int Id { get; set; }
        [Required] public string Username { get; set; } = default!;
        [Required] public string Email { get; set; } = default!;
        [Required] public string PasswordHash { get; set; } = default!;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        [ForeignKey("Role")] public int RoleId { get; set; }
        public Role? Role { get; set; }
        public string CountryCode { get; set; } = "ALL";
        public int? PaymentMethodId { get; set; }
        public PaymentMethod? PaymentMethod { get; set; }
    }

    public class Restaurant : IHasCountry
    {
        public int Id { get; set; }
        [Required] public string Name { get; set; } = default!;
        [Required] public string CountryCode { get; set; } = default!;
        public List<MenuItem> Menu { get; set; } = new();
    }

    public class MenuItem
    {
        public int Id { get; set; }
        [ForeignKey("Restaurant")] public int RestaurantId { get; set; }
        public Restaurant? Restaurant { get; set; }
        [Required] public string Name { get; set; } = default!;
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public bool IsAvailable { get; set; } = true;
    }

    public enum OrderStatus { Created = 0, Placed = 1, Canceled = 2, Completed = 3 }

    public class Order : IHasCountry
    {
        public int Id { get; set; }
        [ForeignKey("User")] public int UserId { get; set; }
        public User? User { get; set; }
        [ForeignKey("Restaurant")] public int RestaurantId { get; set; }
        public Restaurant? Restaurant { get; set; }
        public List<OrderItem> Items { get; set; } = new();
        public decimal TotalAmount { get; set; }
        public OrderStatus Status { get; set; } = OrderStatus.Created;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public string CountryCode { get; set; } = "ALL";
    }

    public class OrderItem
    {
        public int Id { get; set; }
        [ForeignKey("Order")] public int OrderId { get; set; }
        public Order? Order { get; set; }

        [ForeignKey("MenuItem")] public int MenuItemId { get; set; }
        public MenuItem? MenuItem { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
    }

    public class PaymentMethod
    {
        public int Id { get; set; }
        [ForeignKey("User")] public int UserId { get; set; }
        public User? User { get; set; }
        public string Type { get; set; } = "Card";
        public string DetailsMasked { get; set; } = default!;
    }
}
