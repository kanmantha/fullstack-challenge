namespace SloozeFoodApp.Models
{
    public interface IHasCountry
    {
        string CountryCode { get; }
    }
}
