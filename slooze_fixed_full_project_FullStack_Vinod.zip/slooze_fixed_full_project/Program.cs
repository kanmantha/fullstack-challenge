﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SloozeFoodApp.Data;
using SloozeFoodApp.Models;
using SloozeFoodApp.Services;
using System.Data;
using System.Linq;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// -----------------------------
// Services
// -----------------------------
builder.Services.AddControllers().AddJsonOptions(o=>{o.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// DbContext - SQLite
var conn = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlite(conn));

// JWT config
var jwtKey = builder.Configuration["Jwt:Key"];
var jwtIssuer = builder.Configuration["Jwt:Issuer"];
var jwtAudience = builder.Configuration["Jwt:Audience"];
var expireMinutes = int.Parse(builder.Configuration["Jwt:ExpireMinutes"] ?? "60");

builder.Services.AddSingleton(new JwtService(jwtKey!, jwtIssuer!, jwtAudience!, expireMinutes));

// Authentication
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidIssuer = jwtIssuer,
        ValidateAudience = true,
        ValidAudience = jwtAudience,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey!)),
        ValidateLifetime = true
    };
});

// Authorization
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("CanPlaceOrder", policy => policy.RequireAssertion(ctx =>
        ctx.User.IsInRole("Admin") || ctx.User.IsInRole("Manager")));
    options.AddPolicy("CanUpdatePayment", policy => policy.RequireRole("Admin"));
});

var app = builder.Build();


// ========================================================
// PHASE 1 — Ensure critical tables exist before migrations
// ========================================================
using (var scope = app.Services.CreateScope())
{
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var dbConn = (SqliteConnection)db.Database.GetDbConnection();

    if (dbConn.State != ConnectionState.Open) dbConn.Open();

    try
    {
        // Create Roles table (needed for Nick/admin seeding)
        using (var cmd = dbConn.CreateCommand())
        {
            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS ""Roles"" (
                    ""Id"" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    ""Name"" TEXT NOT NULL UNIQUE
                );
            ";
            cmd.ExecuteNonQuery();
        }

        // Create Users table (minimal)
        using (var cmd = dbConn.CreateCommand())
        {
            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS ""Users"" (
                    ""Id"" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    ""Username"" TEXT NOT NULL UNIQUE,
                    ""PasswordHash"" TEXT,
                    ""Email"" TEXT,
                    ""CountryCode"" TEXT,
                    ""PaymentMethodId"" INTEGER,
                    ""RoleId"" INTEGER,
                    ""CreatedAt"" TEXT NOT NULL DEFAULT (datetime('now')),
                    FOREIGN KEY(""RoleId"") REFERENCES ""Roles""(""Id"")
                );
            ";
            cmd.ExecuteNonQuery();
        }

        // Create Restaurants (minimal)
        using (var cmd = dbConn.CreateCommand())
        {
            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS ""Restaurants"" (
                    ""Id"" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    ""Name"" TEXT,
                    ""Address"" TEXT,
                    ""CountryCode"" TEXT,
                    ""CreatedAt"" TEXT
                );
            ";
            cmd.ExecuteNonQuery();
        }

        logger.LogInformation("Critical base tables ensured.");
    }
    finally
    {
        if (dbConn.State == ConnectionState.Open) dbConn.Close();
    }
}

//using (var scope = app.Services.CreateScope())
//{
//    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
//    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
//    var con = (SqliteConnection)db.Database.GetDbConnection();

//    if (con.State != ConnectionState.Open) con.Open();


//    try
//    {
//        if (con.State != ConnectionState.Open) con.Open();

//        bool ColumnExists(string tableName, string columnName)
//        {
//            using var checkCmd = con.CreateCommand();
//            checkCmd.CommandText = $"PRAGMA table_info('{tableName}');";
//            using var rdr = checkCmd.ExecuteReader();
//            while (rdr.Read())
//            {
//                // column name is in the 2nd column (index 1)
//                var col = rdr.GetString(1);
//                if (string.Equals(col, columnName, StringComparison.OrdinalIgnoreCase))
//                    return true;
//            }
//            return false;
//        }

//        if (!ColumnExists("MenuItems", "IsAvailable"))
//        {
//            using var addCmd = con.CreateCommand();
//            addCmd.CommandText = "ALTER TABLE \"MenuItems\" ADD COLUMN \"IsAvailable\" INTEGER DEFAULT 1;";
//            addCmd.ExecuteNonQuery();
//        }

//        if (!ColumnExists("Orders", "CountryCode"))
//        {
//            using var addCmd = con.CreateCommand();
//            addCmd.CommandText = "ALTER TABLE \"Orders\" ADD COLUMN \"CountryCode\" TEXT DEFAULT '';";
//            addCmd.ExecuteNonQuery();
//        }
//    }
//    finally
//    {
//        if (con.State == ConnectionState.Open) con.Close();
//    }
//}
// ========================================================
// PHASE 2 — Run EF Migrations (with diagnostics)
// ========================================================
using (var scope = app.Services.CreateScope())
{
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

    try
    {
        logger.LogInformation("Applying migrations...");
        db.Database.Migrate();
        logger.LogInformation("Migrations applied successfully.");
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Migration failure.");
        throw;
    }
}


// ========================================================
// PHASE 3 — Create/Update default Admin + Nick
// ========================================================
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var connSql = (SqliteConnection)db.Database.GetDbConnection();
    if (connSql.State != ConnectionState.Open) connSql.Open();

    using var tx = connSql.BeginTransaction();

    // 1. Ensure basic roles
    void EnsureRole(string roleName)
    {
        using var cmd = connSql.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText =
            @"INSERT INTO Roles (Name)
              SELECT @name
              WHERE NOT EXISTS (SELECT 1 FROM Roles WHERE Name=@name);";
        cmd.Parameters.AddWithValue("@name", roleName);
        cmd.ExecuteNonQuery();
    }

    EnsureRole("Admin");
    EnsureRole("Manager");
    EnsureRole("Member");

    // 2. Ensure NICK user (admin)
    {
        var password = "P@ssw0rd!";
        var hash = BCrypt.Net.BCrypt.HashPassword(password);

        // Update if exists
        using var u1 = connSql.CreateCommand();
        u1.Transaction = tx;
        u1.CommandText = @"
            UPDATE Users
            SET PasswordHash = @hash,
                RoleId = (SELECT Id FROM Roles WHERE Name='Admin'),
                CreatedAt = COALESCE(CreatedAt, datetime('now'))
            WHERE Username='nick';
        ";
        u1.Parameters.AddWithValue("@hash", hash);
        var updated = u1.ExecuteNonQuery();

        // Insert if missing
        if (updated == 0)
        {
            using var ins = connSql.CreateCommand();
            ins.Transaction = tx;
            ins.CommandText = @"
                INSERT INTO Users
                (Username, Email, PasswordHash, CountryCode, RoleId, CreatedAt)
                VALUES ('nick','nick@example.com',@hash,'GLOBAL',
                    (SELECT Id FROM Roles WHERE Name='Admin'),
                    datetime('now')
                );
            ";
            ins.Parameters.AddWithValue("@hash", hash);
            ins.ExecuteNonQuery();
        }

        Console.WriteLine("User 'nick' ready. Password = P@ssw0rd!");
    }

    tx.Commit();
    connSql.Close();
}


// ========================================================
// PHASE 4 — Legacy admin seeding (kept for compatibility)
// ========================================================
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

    if (!db.Users.Any(u => u.Username == "admin"))
    {
        var pw = "P@ssw0rd!";
        var hashed = BCrypt.Net.BCrypt.HashPassword(pw);

        db.Users.Add(new User
        {
            Username = "admin",
            PasswordHash = hashed,
            Email = "admin@example.com",
            CreatedAt = DateTime.UtcNow,
            RoleId = db.Roles.First(x => x.Name == "Admin").Id
        });

        db.SaveChanges();
        Console.WriteLine("Legacy 'admin' user created. Password = P@ssw0rd!");
    }
}


// ========================================================
// Pipeline
// ========================================================
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseAuthorization();
app.UseStaticFiles();
app.MapControllers();
app.Run();
