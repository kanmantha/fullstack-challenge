# SloozeFoodApp - Starter (SQLite)

## Overview
Starter ASP.NET Core 7 Web API project for the food ordering take-home assignment.
Uses SQLite for ease of local execution.

Seeded users:
- nick / Admin / country=ALL
- capmarvel / Manager / country=IN
- capamerica / Manager / country=US
- thanos / Member / country=IN
- thor / Member / country=IN
- travis / Member / country=US

Password for seeded users: `Password123!`

## Prerequisites
- .NET 7 SDK

## Run locally
1. Open a terminal in the project folder.
2. Restore packages: `dotnet restore`
3. Run the project: `dotnet run`
4. Open Swagger UI: `https://localhost:5001/swagger` (or the printed URL)

Notes:
- Replace the JWT secret in `appsettings.json` before production use.
- The project uses `EnsureCreated()` and seeds initial data automatically on first run.
