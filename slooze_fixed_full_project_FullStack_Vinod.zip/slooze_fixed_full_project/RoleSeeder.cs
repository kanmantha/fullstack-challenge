using System.Threading.Tasks;
using SloozeFoodApp.Data;
using SloozeFoodApp.Models;

namespace SloozeFoodApp.Services
{
    public class RoleSeeder
    {
        private readonly AppDbContext _context;

        public RoleSeeder(AppDbContext context)
        {
            _context = context;
        }

        public async Task SeedAsync()
        {
            // Example: Add roles if they do not exist
            if (!_context.Roles.Any())
            {
                _context.Roles.Add(new Role { Name = "Admin" });
                _context.Roles.Add(new Role { Name = "Manager" });
                _context.Roles.Add(new Role { Name = "User" });
                await _context.SaveChangesAsync();
            }
        }
    }
}   