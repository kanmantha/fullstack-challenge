﻿using System;
using Microsoft.Data.Sqlite;

partial class Program
{
    static int Main(string[] args)
    {
        // Fixes for CS1002, CS1056, CS1010: Correct dbPath assignment
        var dbPath = args.Length > 0 ? args[0] : "";
        Console.WriteLine($"Using DB: {dbPath}");
        if (!System.IO.File.Exists(dbPath))
        {
            Console.WriteLine("ERROR: DB file not found. Please check the path.");
            return 2;
        }

        var connString = new SqliteConnectionStringBuilder { DataSource = dbPath, ForeignKeys = true }.ToString();

        try
        {
            using var conn = new SqliteConnection(connString);
            conn.Open();

            using var tx = conn.BeginTransaction();

            void Exec(string sql)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.Transaction = tx;
                cmd.ExecuteNonQuery();
            }

            // Turn off foreign keys for DDL changes
            Exec("PRAGMA foreign_keys = OFF;");

            // Create Roles table if missing
            Exec(@"
CREATE TABLE IF NOT EXISTS ""Roles"" (
  ""Id"" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  ""Name"" TEXT NOT NULL
);");

            // Create Users table if missing
            Exec(@"
CREATE TABLE IF NOT EXISTS ""Users"" (
  ""Id"" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  ""Username"" TEXT NOT NULL,
  ""PasswordHash"" TEXT,
  ""Email"" TEXT,
  ""CountryCode"" TEXT,
  ""PaymentMethodId"" INTEGER,
  ""RoleId"" INTEGER NOT NULL,
  ""CreatedAt"" TEXT,
  FOREIGN KEY(""RoleId"") REFERENCES ""Roles""(""Id"") ON DELETE NO ACTION
);");

            // Defensive: remove stale index if exists
            Exec("DROP INDEX IF EXISTS \"IX_Users_Username\";");

            // Recreate unique index
            Exec("CREATE UNIQUE INDEX IF NOT EXISTS \"IX_Users_Username\" ON \"Users\" (\"Username\");");

            // Seed roles (insert only if not exists)
            Exec("INSERT INTO Roles (Name) SELECT 'Admin' WHERE NOT EXISTS(SELECT 1 FROM Roles WHERE Name='Admin');");
            Exec("INSERT INTO Roles (Name) SELECT 'User' WHERE NOT EXISTS(SELECT 1 FROM Roles WHERE Name='User');");

            // Turn FK checks back on
            Exec("PRAGMA foreign_keys = ON;");

            tx.Commit();
            conn.Close();

            Console.WriteLine("Success: Roles + Users ensured, index fixed, roles seeded.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERROR: " + ex.ToString());
            return 1;
        }
    }
}



