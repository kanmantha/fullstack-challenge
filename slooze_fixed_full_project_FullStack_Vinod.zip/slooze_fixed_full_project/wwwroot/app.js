const apiBase = '';

function setToken(token) {
  if (token) localStorage.setItem('token', token);
  else localStorage.removeItem('token');
}
function getToken() { return localStorage.getItem('token'); }

document.getElementById('loginBtn').addEventListener('click', async () => {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ username: user, password: pass })
  });
  const data = await res.json();
  if (res.ok) {
    setToken(data.token);
    document.getElementById('loginMsg').innerText = 'Logged in';
    showUserInfo(data);
    loadRestaurants();
    loadOrders();
  } else {
    document.getElementById('loginMsg').innerText = data.message || 'Login failed';
  }
});

document.getElementById('logoutBtn').addEventListener('click', () => {
  setToken(null);
  location.reload();
});

function showUserInfo(data) {
  document.getElementById('auth').classList.add('hidden');
  document.getElementById('userInfo').classList.remove('hidden');
  document.getElementById('who').innerText = document.getElementById('username').value;
  document.getElementById('role').innerText = data.role;
  document.getElementById('country').innerText = data.country;
  document.getElementById('restaurantsSection').classList.remove('hidden');
  document.getElementById('ordersSection').classList.remove('hidden');
}

async function loadRestaurants() {
  const res = await fetch('/api/restaurants', { headers: { 'Authorization': 'Bearer ' + getToken() }});
  if (!res.ok) {
    alert('Error loading restaurants: ' + res.status);
    return;
  }
  const list = await res.json();
  const ul = document.getElementById('restaurants');
  ul.innerHTML = '';
  list.forEach(r => {
    const li = document.createElement('li');
    li.innerHTML = `<strong>${r.name}</strong> (${r.countryCode}) <button data-id="${r.id}" class="viewMenu">Menu</button>`;
    ul.appendChild(li);
  });
  document.querySelectorAll('.viewMenu').forEach(btn => btn.addEventListener('click', async (e) => {
    const id = e.target.getAttribute('data-id');
    await loadMenu(id);
  }));
}

async function loadMenu(id) {
  const res = await fetch('/api/restaurants/' + id + '/menu', { headers: { 'Authorization': 'Bearer ' + getToken() }});
  if (!res.ok) { alert('Cannot load menu: ' + res.status); return; }
  const menu = await res.json();
  document.getElementById('menuSection').classList.remove('hidden');
  const ul = document.getElementById('menu');
  ul.innerHTML = '';
  menu.forEach(m => {
    const li = document.createElement('li');
    li.innerHTML = `${m.name} - $${m.price} <button data-id="${m.id}" data-name="${m.name}" data-price="${m.price}" class="addToCart">Add</button>`;
    ul.appendChild(li);
  });
  document.querySelectorAll('.addToCart').forEach(btn => btn.addEventListener('click', (e) => {
    const id = e.target.getAttribute('data-id');
    const name = e.target.getAttribute('data-name');
    const price = parseFloat(e.target.getAttribute('data-price'));
    addToCart({menuItemId: parseInt(id), name, price, qty:1});
  }));
}

function addToCart(item) {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  cart.push(item);
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
}

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  document.getElementById('cartCount').innerText = cart.length.toString();
}

document.getElementById('viewCartBtn').addEventListener('click', () => {
  document.getElementById('cartSection').classList.remove('hidden');
  renderCart();
});

function renderCart() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const ul = document.getElementById('cartList');
  ul.innerHTML = '';
  cart.forEach((c, i) => {
    const li = document.createElement('li');
    li.innerHTML = `${c.name} x${c.qty} - $${c.price} <button data-i="${i}" class="remove">Remove</button>`;
    ul.appendChild(li);
  });
  document.querySelectorAll('.remove').forEach(btn => btn.addEventListener('click', (e) => {
    const i = parseInt(e.target.getAttribute('data-i'));
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart.splice(i,1);
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
    updateCartCount();
  }));
}

document.getElementById('createOrderBtn').addEventListener('click', async () => {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  if (cart.length === 0) { alert('Cart empty'); return; }
  // assume all items from same restaurant for demo; pick first menu item's restaurant by fetching menu item details via Menu API is skipped.
  // We'll create order for restaurantId = 1 for demo simplicity (Bombay Bites)
  const dto = { restaurantId: 1, items: cart.map(c => ({ menuItemId: c.menuItemId, quantity: c.qty })) };
  const res = await fetch('/api/orders', {
    method: 'POST',
    headers: { 'Content-Type':'application/json', 'Authorization':'Bearer ' + getToken() },
    body: JSON.stringify(dto)
  });
  const data = await res.json();
  if (res.ok) {
    document.getElementById('orderMsg').innerText = 'Order created. ID: ' + data.id;
    localStorage.removeItem('cart');
    updateCartCount();
    loadOrders();
  } else {
    document.getElementById('orderMsg').innerText = 'Error creating order: ' + (data.message || res.status);
  }
});

async function loadOrders() {
  const res = await fetch('/api/orders', { headers: { 'Authorization': 'Bearer ' + getToken() }});
  if (!res.ok) { document.getElementById('ordersList').innerText = 'Unable to load orders'; return; }
  const list = await res.json();
  const ul = document.getElementById('ordersList');
  ul.innerHTML = '';
  list.forEach(o => {
    const li = document.createElement('li');
    li.innerHTML = `Order ${o.id} - Status: ${o.status} - Total: $${o.totalAmount} 
      <button data-id="${o.id}" class="checkoutBtn">Checkout</button>
      <button data-id="${o.id}" class="cancelBtn">Cancel</button>`;
    ul.appendChild(li);
  });
  document.querySelectorAll('.checkoutBtn').forEach(b => b.addEventListener('click', checkout));
  document.querySelectorAll('.cancelBtn').forEach(b => b.addEventListener('click', cancelOrder));
}

async function checkout(e) {
  const id = e.target.getAttribute('data-id');
  const res = await fetch('/api/orders/' + id + '/checkout', { method:'POST', headers:{ 'Authorization':'Bearer ' + getToken() }});
  if (res.ok) {
    alert('Checkout success');
    loadOrders();
  } else {
    const data = await res.json().catch(()=>({}));
    alert('Checkout failed: ' + res.status + ' ' + (data.message || ''));
  }
}

async function cancelOrder(e) {
  const id = e.target.getAttribute('data-id');
  const res = await fetch('/api/orders/' + id + '/cancel', { method:'POST', headers:{ 'Authorization':'Bearer ' + getToken() }});
  if (res.ok) {
    alert('Canceled');
    loadOrders();
  } else {
    const data = await res.json().catch(()=>({}));
    alert('Cancel failed: ' + res.status + ' ' + (data.message || ''));
  }
}

// On page load: if token exists, show user info by introspecting /api/auth/login? (we stored role & country in login response only)
(function init(){
  updateCartCount();
  const token = getToken();
  if (!token) return;
  // We don't have stored role/country except from login; try to call restaurants to see if token works
  fetch('/api/restaurants', { headers:{ 'Authorization':'Bearer ' + token }})
    .then(r => {
      if (!r.ok) { setToken(null); return; }
      // We can't get role/country here easily, so show generic logged-in
      document.getElementById('auth').classList.add('hidden');
      document.getElementById('userInfo').classList.remove('hidden');
      document.getElementById('who').innerText = 'user';
      document.getElementById('role').innerText = '';
      document.getElementById('country').innerText = '';
      document.getElementById('restaurantsSection').classList.remove('hidden');
      document.getElementById('ordersSection').classList.remove('hidden');
      loadRestaurants();
      loadOrders();
    });
})();
